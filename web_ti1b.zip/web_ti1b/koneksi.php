<?php 
$conn = mysqli_connect("localhost", "root", "", "db_ti1b");
if (!$conn) {
	die("Koneksi Error!");
}
 ?>